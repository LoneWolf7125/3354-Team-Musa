package com.se.contactsmanager;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ViewContactsFragment extends Fragment
{
    private static final int STANDARD_APPBAR = 0;
    private static final int SEARCH_APPBAR = 0;
    private int mAppBarState;

    private AppBarLayout viewContactsBar, searchBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_viewcontacts, container, false);
        viewContactsBar = (AppBarLayout) view.findViewById(R.id.viewContactsToolbar);
        searchBar = (AppBarLayout) view.findViewById(R.id.searchToolbar);

        // Navigate to add contacts fragment
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fabAddContact);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

            }
        });

        ImageView ivSearchContact = (ImageView) view.findViewById(R.id.SearchIcon);
        ivSearchContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                toggleToolBarState();

            }
        });

        ImageView ivBackArrow = (ImageView) view.findViewById(R.id.BackArrow);
        ivBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                toggleToolBarState();

            }
        });
        return view;
    }

    private void toggleToolBarState()
    {
        if(mAppBarState == STANDARD_APPBAR)
        {
            setAppBarState(SEARCH_APPBAR);
        }
        else
        {
            setAppBarState(STANDARD_APPBAR);
        }
    }

    private void setAppBarState(int state)
    {
        mAppBarState = state;

        //Hiding Appbar
        if(mAppBarState == STANDARD_APPBAR)
        {
            searchBar.setVisibility(View.GONE);
            viewContactsBar.setVisibility(View.VISIBLE);

            //hide the keyboard
            View view = getView();
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            try{
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
            catch (NullPointerException e){
            }
        }
        else if(mAppBarState == SEARCH_APPBAR)
        {
            viewContactsBar.setVisibility(View.GONE);
            searchBar.setVisibility(viewContactsBar.VISIBLE);

            //open the keyboard
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        }
    }
}
